// 入口文件
console.log('OK')