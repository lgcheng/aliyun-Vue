<template>
  <div>
    <h3>这是Account的登录子组件</h3>
  </div>
</template>

<script>
</script>


<style scoped>
div {
  color: red;
}
</style>
