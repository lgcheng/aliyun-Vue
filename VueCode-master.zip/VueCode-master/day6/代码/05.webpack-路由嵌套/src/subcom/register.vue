<template>
  <div>
    <h3>这是Account的注册子组件</h3>
  </div>
</template>

<script>
</script>


<style>

</style>
